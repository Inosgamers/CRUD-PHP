CREATE DATABASE IF NOT EXISTS crud_mysqli DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;/*Essa linha cria um banco de dados chamado crud_mysqli caso ele ainda não exista, 
com a codificação de caracteres utf8 e a colação utf8_general_ci*/

USE crud_mysqli;/*Esta linha indica que o banco de dados crud_mysqli será utilizado para as próximas operações.*/

DROP TABLE IF EXISTS usuarios;/*Esta linha verifica se a tabela usuarios já existe e, se existir, a exclui para que
uma nova tabela possa ser criada. Se a tabela não existir, esta operação não fará nada.*/

CREATE TABLE IF NOT EXISTS usuarios (/*Esta linha cria uma nova tabela chamada usuarios, com as seguintes colunas:*/
	
	id int(11) NOT NULL AUTO_INCREMENT,/*id: é uma coluna do tipo int com um tamanho máximo de 11 dígitos, 
	que não pode ser nula e é definida como uma chave primária com o atributo AUTO_INCREMENT, 
	o que significa que cada nova linha terá um valor id único e sequencialmente maior que o anterior.*/
	

	nome text NOT NULL,
	email text NOT NULL,
	/*nome e email: são colunas do tipo text que não pode ser nula e armazena o nome do usuário.*/


	telefone int(11) NOT NULL,/*telefone: é uma coluna do tipo int com um tamanho máximo de 11 dígitos que 
	não pode ser nula e armazena o número de telefone do usuário.*/

	dop datetime NOT NULL DEFAULT current_timestamp(),/*dop: é uma coluna do tipo datetime que não pode ser nula
	 e é definida com um valor padrão de current_timestamp(), que é a data e hora atuais. 
	 Essa coluna armazena a data e hora em que o registro foi adicionado.*/

	PRIMARY KEY (id)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;/*A linha final define que a tabela será armazenada com o
 mecanismo de armazenamento MyISAM, com um valor padrão para o atributo AUTO_INCREMENT de 0 
 e o conjunto de caracteres utf8.*/