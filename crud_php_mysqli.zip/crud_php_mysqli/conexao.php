<?php/*Essa linha indica o início do código PHP.*/

	define('DB_SERVER', 'localhost');
	define('DB_USERNAME', 'root');
	define('DB_PASSWORD', '');
	define('DB_NAME', 'crud_mysqli');
	/*Essas linhas definem constantes que serão usadas para fazer a conexão com o banco de dados. DB_SERVER é o endereço do servidor de banco de dados (no caso, localhost), DB_USERNAME é o nome de usuário do banco de dados (no caso, root), DB_PASSWORD é a senha do usuário do banco de dados (no caso, vazia) e DB_NAME é o nome do banco de dados (crud_mysqli).*/

	$conexao = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);/*Esta linha cria uma conexão com o banco de dados usando as constantes definidas anteriormente. A variável $conexao armazena a conexão estabelecida.*/

	if ($conexao === false) {
		die("Erro: Falha ao conectar com o banco de dados!. " . mysqli_connect_error());
	}/*Esta estrutura condicional verifica se a conexão foi estabelecida com sucesso. Se não, a instrução die é executada, encerrando a execução do script e exibindo uma mensagem de erro que inclui a descrição do erro retornado pela função mysqli_connect_error().*/

?><!--Esta linha indica o final do código PHP.-->