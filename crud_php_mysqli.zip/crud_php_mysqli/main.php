<?php/*Essa linha indica o início do código PHP.*/

  session_start();/*Essa linha inicia ou retoma a sessão do usuário. A função session_start() é usada para inicializar uma sessão PHP e permitir que variáveis de sessão sejam usadas no script.*/

  ob_start();/*Essa linha ativa o buffer de saída de PHP. Isso permite que a saída do script seja armazenada em um buffer ao invés de ser enviada para o navegador imediatamente. Isso é útil para que se possa modificar a saída antes de enviá-la para o navegador.*/

  require_once "conexao.php";/*Essa linha inclui o arquivo conexao.php no script atual. O comando require_once é usado para incluir um arquivo apenas uma vez, garantindo que ele não seja incluído novamente em caso de código duplicado. Esse arquivo provavelmente contém as informações de conexão com o banco de dados.*/

  /* Este código abaixo define uma função chamada clear que recebe uma entrada como argumento e retorna a entrada limpa. A função utiliza as seguintes etapas de limpeza:*/
  function clear($input){
  	global $conexao;
  	$var = mysqli_escape_string($conexao, $input);/*mysqli_escape_string() é usada para evitar a inserção de caracteres que possam ser interpretados como comandos SQL, evitando assim ataques de injeção de SQL.*/

  	$var = htmlspecialchars($var);/*htmlspecialchars() é usada para converter caracteres especiais em entidades HTML, evitando ataques XSS (Cross-Site Scripting).*/

  	return $var;
  }

  if(isset($_POST['create'])){/*Esta linha verifica se o formulário foi enviado usando o botão "create". Se sim, o código dentro do bloco de instruções é executado.*/

  	$nome = addslashes(mysqli_escape_string($conexao, $_POST['nome']));
  	$email = addslashes(mysqli_escape_string($conexao, $_POST['email']));
  	$telefone = addslashes(mysqli_escape_string($conexao, $_POST['telefone']));/*Essas três linhas obtêm os valores dos campos do formulário nomeados 'nome', 'email' e 'telefone' e atribuem a variáveis correspondentes. Cada valor é sanitizado usando mysqli_escape_string() e adiciona barras invertidas para caracteres especiais usando addslashes().*/

  	$query = "INSERT INTO usuarios (nome, email, telefone) VALUES ('$nome', '$email', '$telefone')";/*Esta linha cria uma consulta SQL para inserir os valores dos campos do formulário na tabela 'usuarios'.*/

  	if (mysqli_query($conexao, $query)) {/*Esta linha executa a consulta SQL usando a função mysqli_query() e verifica se ela foi executada com sucesso.*/

  		$_SESSION['msg'] ="<div class='alert alert-success' role='alert'>
							  Cadastrado com sucesso!
							</div>";
		header('Location: index.php');/*Se a consulta for executada com sucesso, a mensagem de sucesso é armazenada na variável $_SESSION['msg'] e a página é redirecionada para 'index.php'.*/
  	}else{
  		$_SESSION['msg'] ="<div class='alert alert-danger' role='alert'>
							  Erro ao cadastrar.
							</div>";
		header('Location: index.php');/*Se a consulta não for executada com sucesso, a mensagem de erro é armazenada na variável $_SESSION['msg'] e a página é redirecionada para 'index.php'.*/
  	}

  }elseif(isset($_POST['update'])){/*Esta linha verifica se o formulário foi enviado usando o botão "update". Se sim, o código dentro do bloco de instruções é executado.*/

  	$id = addslashes(mysqli_escape_string($conexao, $_POST['id']));
  	$nome = addslashes(mysqli_escape_string($conexao, $_POST['nome']));
  	$email = addslashes(mysqli_escape_string($conexao, $_POST['email']));
  	$telefone = addslashes(mysqli_escape_string($conexao, $_POST['telefone']));

  	$query = "UPDATE usuarios SET nome = '$nome', email = '$email', telefone = '$telefone' WHERE usuarios.id='$id'";/*Esta linha cria uma consulta SQL para atualisar os valores dos campos do formulário na tabela 'usuarios'.*/

  	if(mysqli_query($conexao, $query)) {

  		$_SESSION['msg'] ="<div class='alert alert-success' role='alert'>
							  Alterado com sucesso!
							</div>";
		header("Location: perfil.php?id=$id");
  	}else{
  		$_SESSION['msg'] ="<div class='alert alert-danger' role='alert'>
							  Erro ao Alterar.
							</div>";
		header("Location: perfil.php?id=$id");
  	}

  }elseif(isset($_POST['delete'])){/*Esta linha verifica se o formulário foi enviado usando o botão "delete". Se sim, o código dentro do bloco de instruções é executado.*/

  	$id = addslashes(mysqli_escape_string($conexao, $_POST['id']));/* Esta linha pega o valor do campo "id" enviado pelo formulário e faz a sanitização de dados com a função mysqli_escape_string().*/

  	$query = "DELETE FROM usuarios WHERE usuarios.id='$id'";/* Esta linha define a query SQL para excluir um registro da tabela "usuarios" com o ID igual ao valor obtido na linha anterior. */

  	if(mysqli_query($conexao, $query)) {

  		$_SESSION['msg'] ="<div class='alert alert-success' role='alert'>
							  Excluido com sucesso!
							</div>";
		header("Location: index.php?id=$id");
  	}else{
  		$_SESSION['msg'] ="<div class='alert alert-danger' role='alert'>
							  Erro ao Excluir.
							</div>";
		header("Location: perfil.php?id=$id");
  	}
  }

?>