<?php/*Essa linha indica o início do código PHP.*/

  session_start();/*Essa linha inicia ou retoma a sessão do usuário. A função session_start() é usada para inicializar uma sessão PHP e permitir que variáveis de sessão sejam usadas no script.*/

  ob_start();/*Essa linha ativa o buffer de saída de PHP. Isso permite que a saída do script seja armazenada em um buffer ao invés de ser enviada para o navegador imediatamente. Isso é útil para que se possa modificar a saída antes de enviá-la para o navegador.*/

  require_once "conexao.php";/*Essa linha inclui o arquivo conexao.php no script atual. O comando require_once é usado para incluir um arquivo apenas uma vez, garantindo que ele não seja incluído novamente em caso de código duplicado. Esse arquivo provavelmente contém as informações de conexão com o banco de dados.*/

?><!--Esta linha indica o final do código PHP.-->

<!doctype html>
<html lang="pt" data-bs-theme="auto">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="CRUD com PHP e MySQLi usando o framework Botstrap">
    <meta name="author" content="Manuel Inocêncio Gonçalves de Lemos">
    <meta name="generator" content="DOZERO">
    <title>CRUD | Home</title>
    <link href="docs/css/bootstrap.min.css" rel="stylesheet">
    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        width: 100%;
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }

      .btn-bd-primary {
        --bd-violet-bg: #712cf9;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #6528e0;
        --bs-btn-hover-border-color: #6528e0;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #5a23c8;
        --bs-btn-active-border-color: #5a23c8;
      }
      .bd-mode-toggle {
        z-index: 1500;
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="docs/css/style.css" rel="stylesheet">
  </head>
  <body class="text-center">
    <main class="form-signin w-100 m-auto">
      <form action="main.php" method="POST"><!-- Essa linha de código HTML cria um formulário que envia dados para a página "main.php" usando o método HTTP POST. Quando o usuário clicar no botão de envio do formulário, os dados preenchidos no formulário serão enviados para o arquivo "main.php" para processamento. -->

        <img class="mb-4" src="docs/img/dozero.png" alt="" width="72" height="57">
        <h1 class="h3 mb-3 fw-normal">CRUD com PHP e MySQLi</h1>
        <?php/*Essa linha indica o início do código PHP.*/

          if (isset($_SESSION['msg'])) {/*Essa estrutura condicional verifica se a variável de sessão $_SESSION['msg'] foi definida. isset() é uma função do PHP que verifica se uma variável foi definida e não é nula. Nesse caso, a variável de sessão $_SESSION['msg'] é definida quando há uma mensagem para ser exibida.*/

            echo $_SESSION['msg'];/*Se a variável de sessão $_SESSION['msg'] for definida, essa linha exibe o valor da variável usando o comando echo. O valor da variável é a mensagem a ser exibida.*/

            unset($_SESSION['msg']);/*Esta linha remove a variável de sessão $_SESSION['msg'] para que a mensagem não seja exibida novamente na próxima vez que a página for carregada.*/

          }
        ?><!--Esta linha indica o final do código PHP.-->
        <div class="form-floating">
          <input type="text" class="form-control" id="floatingNome" name="nome" placeholder="Digite um nome" required>
          <label for="floatingNome">Nome</label>
        </div>

        <div class="form-floating">
          <input type="email" class="form-control" id="floatingInput" name="email" placeholder="nome@dominio.com" required>
          <label for="floatingInput">E-mail</label>
        </div>

        <div class="form-floating">
          <input type="number" class="form-control" id="floatingTelefone" name="telefone" required>
          <label for="floatingTelefone">Telefone</label>
        </div>

        <div class="d-flex justify-content-between">
          <button class="w-50 btn btn-sm btn-primary me-2" type="submit" name="create">Cadastrar</button>
          <button class="w-50 btn btn-sm btn-secondary me-2" type="reset" name="Limpar">Limpar</button>
          <!-- O primeiro botão, é um botão de Cadastrar que envia o formulário de Cadastro para o servidor quando clicado. O atributo "type" define o tipo do botão como "submit", que é usado para enviar dados de formulário para o servidor. O atributo "name" é definido como "update", que é usado para identificar o botão no script PHP que processa a solicitação do cadastro.

          O segundo botão, cria um botão com o texto "Limpar" e algumas classes CSS que definem a aparência do botão. Ao ser clicado, esse botão irá resetar os campos do formulário para seus valores padrão ou vazios, dependendo do tipo de campo. O atributo "type" está definido como "reset", indicando que esse botão irá resetar o formulário. O atributo "name" é definido como "Limpar", mas esse valor não é usado no processamento do formulário no lado do servidor, ele é usado principalmente para identificar o botão no lado do cliente ou em scripts JavaScript. -->
        </div>

      </form>
    </main>

    <div class="container">
      <div class="row">
        <table class="table table-sm table-hover">
          <caption>Lista de usuários</caption>
          <thead>
            <tr>
              <th scope="col">Nome</th>
              <th scope="col">E-mail</th>
              <th scope="col">Telefone</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $query = "SELECT * FROM usuarios ORDER BY id DESC";/*Esta linha define a consulta SQL para recuperar os dados dos usuários do banco de dados. Neste caso, a consulta seleciona todos os campos da tabela usuarios e os ordena pelo id em ordem descendente.*/

              $resutado = mysqli_query($conexao, $query);/*Esta linha executa a consulta SQL e armazena o resultado na variável $resutado. A função mysqli_query() é usada para executar uma consulta SQL no banco de dados.*/

              if (mysqli_num_rows($resutado)) {/*Esta estrutura condicional verifica se o resultado da consulta SQL retornou algum registro. mysqli_num_rows() é uma função do PHP que retorna o número de linhas em um resultado de consulta.*/

                while ($dados = mysqli_fetch_array($resutado)) {/*Este laço de repetição while itera através de cada linha do resultado da consulta SQL e armazena os dados da linha em um array associativo $dados. mysqli_fetch_array() é uma função do PHP que retorna uma linha do resultado da consulta como um array.*/
            ?>
              <tr data-href="perfil.php?id=<?= $dados['id'] ?>" style="cursor: pointer;"><!-- Esta linha define uma linha da tabela HTML para exibir os dados do usuário. O atributo data-href é usado para armazenar o link para o perfil do usuário. A variável $dados['id'] é usada para definir o ID do usuário no link. -->

                <td><?= $dados['nome'] ?></td>
                <td><?= $dados['email'] ?></td>
                <td><?= $dados['telefone'] ?></td><!--Estas linhas definem as células da tabela HTML para exibir os dados do usuário. Os valores das células são obtidos a partir do array associativo $dados usando as chaves nome, email e telefone.-->
              </tr>
            <?php
              }}else{ 
            ?><!--Este bloco de código PHP é usado para exibir uma mensagem caso não existam usuários registrados. Se o número de linhas retornadas pela consulta SQL for zero, o bloco else é executado.-->
          </tbody>
        </table>
        <center>Nenhum usuário encontrado.</center><!--Este código HTML é usado para exibir a mensagem "Nenhum usuário encontrado." no centro da página quando não houver usuários registrados.-->
        <?php
          }
        ?>
        <script type="text/javascript">
          // Adiciona um ouvinte de eventos para o evento "DOMContentLoaded", que é acionado quando a página é totalmente carregada e pronta para manipulação.
          document.addEventListener("DOMContentLoaded", () => {

            // Seleciona todas as linhas da tabela que contêm o atributo "data-href" e as armazena em uma variável chamada "rows".
            const rows = document.querySelectorAll("tr[data-href");

            // Itera sobre cada linha selecionada e adiciona um ouvinte de eventos para o evento "click".
            rows.forEach(row => {
              row.addEventListener("click", () => {

                // Redireciona o navegador para a URL armazenada no atributo "data-href" da linha clicada.
                window.location.href = row.dataset.href;
              });
            });
          });
        </script>
      </div>
    </div>
  </body>
</html>
