<?php/*Essa linha indica o início do código PHP.*/

  session_start();/*Essa linha inicia ou retoma a sessão do usuário. A função session_start() é usada para inicializar uma sessão PHP e permitir que variáveis de sessão sejam usadas no script.*/

  ob_start();/*Essa linha ativa o buffer de saída de PHP. Isso permite que a saída do script seja armazenada em um buffer ao invés de ser enviada para o navegador imediatamente. Isso é útil para que se possa modificar a saída antes de enviá-la para o navegador.*/

  require_once "conexao.php";/*Essa linha inclui o arquivo conexao.php no script atual. O comando require_once é usado para incluir um arquivo apenas uma vez, garantindo que ele não seja incluído novamente em caso de código duplicado. Esse arquivo provavelmente contém as informações de conexão com o banco de dados.*/

  if (isset($_GET['id'])) {/*Este código verifica se existe um parâmetro "id" na URL da página. Caso exista, o código dentro do bloco será executado.*/

    $id = mysqli_escape_string($conexao, $_GET['id']);/*Aqui, o valor do parâmetro "id" é atribuído à variável $id. O mysqli_escape_string é uma função para prevenir SQL Injection.*/

    $query = "SELECT * FROM usuarios WHERE usuarios.id='$id'";/*Esta é a consulta SQL que seleciona todos os campos da tabela "usuarios" onde o id é igual ao valor da variável $id.*/

    $resultado = mysqli_query($conexao, $query);/*O mysqli_query é uma função que executa a consulta SQL na conexão com o banco de dados. O resultado é armazenado na variável $resultado.*/

    $dados =mysqli_fetch_array($resultado);/*O mysqli_fetch_array é uma função que retorna a próxima linha do resultado da consulta como um array associativo.*/

    $id = $dados['id'];
    $nome = $dados['nome'];
    $email = $dados['email'];
    $telefone = $dados['telefone'];/*As variáveis $id, $nome, $email e $telefone são atribuídas aos valores da array associativa $dados.*/

    /*
      Em resumo, este código recupera informações de um usuário específico da tabela "usuarios" do banco de dados, com base no valor do parâmetro "id" passado pela URL.
    */
  }

?>

<!doctype html>
<html lang="pt" data-bs-theme="auto">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="CRUD com PHP e MySQLi usando o framework Botstrap">
    <meta name="author" content="Manuel Inocêncio Gonçalves de Lemos">
    <meta name="generator" content="DOZERO">
    <title>CRUD | Perfil</title>
    <link href="docs/css/bootstrap.min.css" rel="stylesheet">
    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        width: 100%;
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }

      .btn-bd-primary {
        --bd-violet-bg: #712cf9;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #6528e0;
        --bs-btn-hover-border-color: #6528e0;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #5a23c8;
        --bs-btn-active-border-color: #5a23c8;
      }
      .bd-mode-toggle {
        z-index: 1500;
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="docs/css/style.css" rel="stylesheet">
  </head>
  <body class="text-center">
    <main class="form-signin w-100 m-auto">
      <form action="main.php" method="POST"><!-- Essa linha de código HTML cria um formulário que envia dados para a página "main.php" usando o método HTTP POST. Quando o usuário clicar no botão de envio do formulário, os dados preenchidos no formulário serão enviados para o arquivo "main.php" para processamento. -->

        <img class="mb-4" src="docs/img/dozero.png" alt="" width="72" height="57">
        <h1 class="h3 mb-3 fw-normal">CRUD com PHP e MySQLi</h1>
        <?php/*Essa linha indica o início do código PHP.*/

          if (isset($_SESSION['msg'])) {/*Essa estrutura condicional verifica se a variável de sessão $_SESSION['msg'] foi definida. isset() é uma função do PHP que verifica se uma variável foi definida e não é nula. Nesse caso, a variável de sessão $_SESSION['msg'] é definida quando há uma mensagem para ser exibida.*/

            echo $_SESSION['msg'];/*Se a variável de sessão $_SESSION['msg'] for definida, essa linha exibe o valor da variável usando o comando echo. O valor da variável é a mensagem a ser exibida.*/

            unset($_SESSION['msg']);/*Esta linha remove a variável de sessão $_SESSION['msg'] para que a mensagem não seja exibida novamente na próxima vez que a página for carregada.*/

          }
        ?><!--Esta linha indica o final do código PHP.-->


        <!-- O valor '$dados['nome']' no atributo 'value' em id, nome, email e telefone é a forma abreviada do PHP de imprimir uma variável dentro do HTML. Quando o código é executado, o valor atual da variável '$dados['nome']' será impresso na tag HTML que contém esse atributo. -->

        <input type="hidden" name="id" value="<?= $dados['id'] ?>">
        <div class="form-floating">
          <input type="text" class="form-control" id="floatingNome" name="nome" placeholder="Digite um nome" value="<?= $dados['nome'] ?>" required>
          <label for="floatingNome">Nome</label>
        </div>

        <div class="form-floating">
          <input type="email" class="form-control" id="floatingInput" name="email" placeholder="nome@dominio.com" value="<?= $dados['email'] ?>" required>
          <label for="floatingInput">E-mail</label>
        </div>

        <div class="form-floating">
          <input type="number" class="form-control" id="floatingTelefone" name="telefone" value="<?= $dados['telefone'] ?>" required>
          <label for="floatingTelefone">Telefone</label>
        </div>

        <div class="d-flex justify-content-between">
          <button class="w-50 btn btn-sm btn-warning me-2" type="submit" name="update">Atualizar</button>
          <button class="w-50 btn btn-sm btn-danger me-2" type="submit" name="delete">Excluir</button>
          <!-- O primeiro botão, é um botão de atualização que envia o formulário de atualização para o servidor quando clicado. O atributo "type" define o tipo do botão como "submit", que é usado para enviar dados de formulário para o servidor. O atributo "name" é definido como "update", que é usado para identificar o botão no script PHP que processa a solicitação de atualização.

          O segundo botão, é um botão de exclusão que também envia o formulário para o servidor quando clicado. O atributo "type" é definido como "submit", e o atributo "name" é definido como "delete", para identificar o botão no script PHP que processa a solicitação de exclusão. -->
                  </div>

        <br><br><br>
        <a href="index.php">Voltar</a>
      </form>
    </main>
  </body>
</html>
